/*
ARDUINO TRAINING 
CREATE BY : MUHAMMAD SHAHKHIR BIN MOZAMIR

 TITLE: 1 LED CONNECTION
*/

int LED1=13;  
int LED2=12;
int LED3=11;  
//all the pin attach on Arduino board must be declare


void setup() { 
  //function setup to declare the component is INPUT or OUTPUT
  pinMode(13,OUTPUT);
  pinMode(12,OUTPUT);
  pinMode(11,OUTPUT);

Serial.begin(9600);
  //Serial.begin is to connect to serial monitor
}

void loop() {
  // function loop is for repeat the activity 
  
  digitalWrite(LED1,HIGH); //HIGH mean the allow the current
  digitalWrite(LED2,LOW); //HIGH mean the allow the current
  digitalWrite(LED3,LOW); //HIGH mean the allow the current
  delay(3000);  //2000milisecond = 1 second
    digitalWrite(LED1,LOW); //HIGH mean the allow the current
    digitalWrite(LED2,HIGH); //HIGH mean the allow the current
    digitalWrite(LED3,LOW); //HIGH mean the allow the current
  delay(3000);
  digitalWrite(LED1,LOW); //HIGH mean the allow the current
  digitalWrite(LED2,LOW); //HIGH mean the allow the current
  digitalWrite(LED3,HIGH); //HIGH mean the allow the current
  delay(3000);
}


/*
 *TEST STATUS : QUALIFIED
 */
